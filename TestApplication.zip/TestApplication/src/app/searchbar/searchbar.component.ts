import { Component, OnInit,EventEmitter,Output } from '@angular/core';
import { ProductService } from '../services/productService';

@Component({
  selector: 'app-searchbar',
  templateUrl: './searchbar.component.html',
  styleUrls: ['./searchbar.component.css']
})
export class SearchBarComponent implements OnInit {

  @Output() searchBoxChanged: EventEmitter<any> = new EventEmitter();
  @Output() inStockChanged: EventEmitter<boolean> = new EventEmitter();

searchValue:string;
checkBoxStatus:boolean;
  constructor(public ps:ProductService) {
    this.searchValue=" ";
    this.checkBoxStatus=false;
     }
     onInStockChecked(value: boolean): void {
      this.inStockChanged.emit(this.checkBoxStatus);
    }
  
    onSearchBoxChanged(value: string): void {
      this.searchValue = value;
      this.searchBoxChanged.emit(this.searchValue);
    }
  ngOnInit(): void {
  }

}
