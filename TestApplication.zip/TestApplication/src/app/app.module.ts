import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FilterableProductTableComponent } from './filterableproducttable/filterableproducttable.component';
import { SearchBarComponent } from './searchbar/searchbar.component';
import { ProductTableComponent } from './producttable/producttable.component';
import { ProductCategoryRowComponent } from './productcategoryrow/productcategoryrow.component';
import { ProductRowComponent } from './productrow/productrow.component';

@NgModule({
  declarations: [
    AppComponent,
    FilterableProductTableComponent,
    SearchBarComponent,
    ProductTableComponent,
    ProductCategoryRowComponent,
    ProductRowComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
