import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { ProductService,Product } from '../services/productService';

@Component({
  selector: 'app-productcategoryrow',
  templateUrl: './productcategoryrow.component.html',
  styleUrls: ['./productcategoryrow.component.css']
})
export class ProductCategoryRowComponent implements OnInit,OnChanges {
  
products!:Product[];
@Input()
category!:string;
@Input()
searchValue!:string;
@Input()
instock!:boolean;
  constructor(public productService:ProductService) {
   }

  ngOnInit(): void {
    let categorySpecificProducts = this.productService.getProductList().filter(v=>v.category.toLowerCase()==this.category.toLowerCase());
    this.products=categorySpecificProducts;
  }
  ngOnChanges()
  {

    if(this.searchValue !== " ")
    {
      this.GetProductsBasedOnSearchValueandStock();
      
    }

    else{
      this.GetAllProducts();     
    }
  }


  private GetAllProducts() {
    if (this.instock) {

      this.products = this.productService.getProductList().filter(x => x.category.toLowerCase() == this.category.toLowerCase()
        && x.stock == this.instock);
    }
    else {
      let categorySpecificProducts = this.productService.getProductList().filter(x => x.category.toLowerCase() == this.category.toLowerCase());
      this.products = categorySpecificProducts;
    }
  }

  private GetProductsBasedOnSearchValueandStock() {
    if (this.instock) {
      this.products = this.productService.getProductList().filter(x => x.category.toLowerCase() == this.category.toLowerCase()
        && x.name.toLowerCase().includes(this.searchValue.toLowerCase()) && x.stock == this.instock);
    }
    else {
      this.products = this.productService.getProductList().filter(x => x.category.toLowerCase() == this.category.toLowerCase() &&
        x.name.toLowerCase().includes(this.searchValue.toLowerCase()));
    }
  }
}
