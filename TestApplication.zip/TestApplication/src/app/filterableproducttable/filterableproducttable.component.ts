import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filterableproducttable',
  templateUrl: './filterableproducttable.component.html',
  styleUrls: ['./filterableproducttable.component.css']
})
export class FilterableProductTableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
