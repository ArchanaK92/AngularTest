import { Component, Input, OnInit } from '@angular/core';
import { ProductService,Product } from '../services/productService';

@Component({
  selector: 'app-producttable',
  templateUrl: './producttable.component.html',
  styleUrls: ['./producttable.component.css']
})
export class ProductTableComponent implements OnInit {

products!:Product[]
categories!:Set<string>;
@Input()
instock!:boolean
@Input()
searchValue!:string
  constructor(public ps:ProductService) { 
    this.products=this.ps.getProductList(); 
    this.categories=this.ps.getCategories();
    console.log(this.categories.values())  
  }

  ngOnInit(): void {
       
  }

}
